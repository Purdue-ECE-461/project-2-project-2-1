package com.commcourier.exceptions;

import com.commcourier.restartifacts.BaseResponse;
import com.commcourier.utilities.ResponseUtils;

import javax.inject.Inject;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

@Provider
public class CommcourierExceptionMapper implements ExceptionMapper<CommcourierException> {

    @Inject
    ResponseUtils responseUtils;

    @Override
    public Response toResponse(CommcourierException ex) {

        BaseResponse response = new BaseResponse();

        return responseUtils.updateResponseData(response, ex.getResponseCode());

    }
}
