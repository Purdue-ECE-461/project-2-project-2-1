package com.commcourier.exceptions;

import com.commcourier.restartifacts.BaseResponse;
import com.commcourier.restartifacts.ResponseCode;
import com.commcourier.utilities.ResponseUtils;

import javax.inject.Inject;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Provider
public class GenericExceptionMapper implements ExceptionMapper<Exception> {

    @Inject
    ResponseUtils responseUtils;

    @Override
    public Response toResponse(Exception ex) {

        BaseResponse response = new BaseResponse();

        log.error("An exception was thrown", ex);

        return responseUtils.updateResponseDataWithDescription(response, ResponseCode.ERROR, ex.getLocalizedMessage());

    }
}
